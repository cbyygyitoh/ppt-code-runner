import tkinter as tk
from tkinter import scrolledtext, messagebox
import subprocess
import sys
import os
import tempfile
from pathlib import Path
import traceback
import ctypes
import re


# ========== 防止重复启动（使用互斥体） ==========
def prevent_multiple_instances():
    """防止程序重复运行（Windows 互斥体）"""
    if sys.platform == 'win32':
        try:
            kernel32 = ctypes.windll.kernel32
            mutex = kernel32.CreateMutexW(None, False, "PPTCodeRunner_Mutex")
            if kernel32.GetLastError() == 183:
                try:
                    hwnd = ctypes.windll.user32.FindWindowW(None, "PPT 代码快捷运行器")
                    if hwnd:
                        ctypes.windll.user32.ShowWindow(hwnd, 5)
                        ctypes.windll.user32.SetForegroundWindow(hwnd)
                        ctypes.windll.user32.BringWindowToTop(hwnd)
                except:
                    pass
                sys.exit(0)
            return mutex
        except:
            pass
    return None


mutex = prevent_multiple_instances()


# ========== 主程序 ==========
class PPTCodeRunner:
    def __init__(self, master):
        self.master = master
        master.title("PPT 代码快捷运行器")
        master.geometry("700x680")
        master.resizable(True, True)

        master.configure(bg='#f0f4f8')

        title_label = tk.Label(master, text="📊 PPT 代码快捷运行器",
                               font=("Segoe UI", 16, "bold"),
                               bg='#f0f4f8', fg='#2c3e50')
        title_label.pack(pady=(15, 5))

        desc_label = tk.Label(master,
                              text="将 AI 生成的 PPT 代码粘贴至下方，点击「运行」即可生成并打开 PPT",
                              font=("Segoe UI", 10),
                              bg='#f0f4f8', fg='#34495e')
        desc_label.pack(pady=(0, 10))

        self.code_input = scrolledtext.ScrolledText(master,
                                                    wrap=tk.NONE,
                                                    font=("Consolas", 10),
                                                    bg='#ffffff',
                                                    fg='#000000',
                                                    insertbackground='red',
                                                    height=18,
                                                    relief=tk.FLAT,
                                                    borderwidth=2,
                                                    highlightthickness=1,
                                                    highlightcolor='#3498db')
        self.code_input.pack(padx=20, pady=5, fill=tk.BOTH, expand=True)

        self.code_input.bind('<Control-a>', self.select_all)
        self.code_input.bind('<Control-A>', self.select_all)

        # 错误信息显示区
        self.error_frame = tk.Frame(master, bg='#fdf0ed', relief=tk.SUNKEN, bd=1)

        self.error_text = scrolledtext.ScrolledText(
            self.error_frame,
            height=6,
            bg='#fff5f5',
            fg='#cc0000',
            font=("Consolas", 9),
            wrap=tk.WORD
        )
        self.error_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(5, 0), pady=5)

        error_btn_frame = tk.Frame(self.error_frame, bg='#fdf0ed')
        error_btn_frame.pack(side=tk.RIGHT, padx=5, pady=5, fill=tk.Y)

        copy_btn = tk.Button(
            error_btn_frame,
            text="📋 复制错误",
            command=self.copy_error,
            bg='#e74c3c',
            fg='white',
            padx=10,
            pady=5,
            font=("Segoe UI", 9)
        )
        copy_btn.pack(side=tk.TOP, pady=2)

        close_error_btn = tk.Button(
            error_btn_frame,
            text="✕ 关闭",
            command=self.hide_error,
            bg='#95a5a6',
            fg='white',
            padx=10,
            pady=5,
            font=("Segoe UI", 9)
        )
        close_error_btn.pack(side=tk.TOP, pady=2)

        button_frame = tk.Frame(master, bg='#f0f4f8')
        button_frame.pack(pady=8)

        run_btn = tk.Button(button_frame, text="▶ 运行并生成 PPT",
                            command=self.run_code,
                            font=("Segoe UI", 11, "bold"),
                            bg='#2ecc71', fg='white',
                            padx=25, pady=8,
                            relief=tk.RAISED, borderwidth=2,
                            activebackground='#27ae60')
        run_btn.grid(row=0, column=0, padx=10)

        clear_btn = tk.Button(button_frame, text="🗑 清空代码",
                              command=self.clear_code,
                              font=("Segoe UI", 11),
                              bg='#e74c3c', fg='white',
                              padx=20, pady=8,
                              relief=tk.RAISED, borderwidth=2,
                              activebackground='#c0392b')
        clear_btn.grid(row=0, column=1, padx=10)

        example_btn = tk.Button(button_frame, text="📋 加载示例代码",
                                command=self.load_example,
                                font=("Segoe UI", 11),
                                bg='#3498db', fg='white',
                                padx=20, pady=8,
                                relief=tk.RAISED, borderwidth=2,
                                activebackground='#2980b9')
        example_btn.grid(row=0, column=2, padx=10)

        self.status_var = tk.StringVar()
        self.status_var.set("✅ 就绪 | 请粘贴 AI 生成的 PPT 代码")
        status_bar = tk.Label(master, textvariable=self.status_var,
                              bd=1, relief=tk.SUNKEN, anchor=tk.W,
                              font=("Segoe UI", 9),
                              bg='#ecf0f1', fg='#2c3e50')
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        self.pptx_available = False
        self.check_dependencies()

    def select_all(self, event=None):
        self.code_input.tag_add('sel', '1.0', 'end')
        return 'break'

    def clear_code(self):
        self.code_input.delete('1.0', tk.END)
        self.hide_error()
        self.status_var.set("🗑 已清空代码")

    def load_example(self):
        example_code = '''from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.dml.color import RGBColor
from pathlib import Path
from datetime import datetime

def create_ppt():
    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)

    # 封面
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = RGBColor(44, 62, 80)
    bg.line.fill.background()

    title_box = slide.shapes.add_textbox(Inches(1), Inches(2.2), Inches(11.33), Inches(1.5))
    tf = title_box.text_frame
    tf.text = "AI 赋能未来"
    tf.paragraphs[0].font.size = Pt(54)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = RGBColor(255, 255, 255)
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER

    sub_box = slide.shapes.add_textbox(Inches(1), Inches(4), Inches(11.33), Inches(1))
    tf = sub_box.text_frame
    tf.text = "智能 · 高效 · 创新"
    tf.paragraphs[0].font.size = Pt(28)
    tf.paragraphs[0].font.color.rgb = RGBColor(200, 200, 200)
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER

    # 内容页
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    bg = slide.shapes.add_shape(1, 0, 0, prs.slide_width, prs.slide_height)
    bg.fill.solid()
    bg.fill.fore_color.rgb = RGBColor(240, 244, 248)
    bg.line.fill.background()

    title_box = slide.shapes.add_textbox(Inches(1), Inches(0.5), Inches(11.33), Inches(1))
    tf = title_box.text_frame
    tf.text = "核心优势"
    tf.paragraphs[0].font.size = Pt(40)
    tf.paragraphs[0].font.bold = True
    tf.paragraphs[0].font.color.rgb = RGBColor(44, 62, 80)
    tf.paragraphs[0].alignment = PP_ALIGN.CENTER

    points = [
        ("极速响应", "毫秒级生成，告别等待"),
        ("精准定制", "针对需求，量身打造"),
        ("持续进化", "自我学习，不断优化")
    ]
    x_positions = [1.5, 5.5, 9.5]
    y_pos = 2.5

    for i, (title, desc) in enumerate(points):
        circle = slide.shapes.add_shape(9, Inches(x_positions[i]), Inches(y_pos-0.3), Inches(1.2), Inches(1.2))
        circle.fill.solid()
        circle.fill.fore_color.rgb = RGBColor(52, 152, 219)
        circle.line.fill.background()

        tb = slide.shapes.add_textbox(Inches(x_positions[i]-0.5), Inches(y_pos+0.8), Inches(2.2), Inches(0.8))
        tf = tb.text_frame
        tf.text = title
        tf.paragraphs[0].font.size = Pt(22)
        tf.paragraphs[0].font.bold = True
        tf.paragraphs[0].font.color.rgb = RGBColor(44, 62, 80)
        tf.paragraphs[0].alignment = PP_ALIGN.CENTER

        db = slide.shapes.add_textbox(Inches(x_positions[i]-0.8), Inches(y_pos+1.6), Inches(2.8), Inches(0.6))
        df = db.text_frame
        df.text = desc
        df.paragraphs[0].font.size = Pt(16)
        df.paragraphs[0].font.color.rgb = RGBColor(100, 100, 100)
        df.paragraphs[0].alignment = PP_ALIGN.CENTER

    desktop = Path.home() / "Desktop"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = desktop / f"AI_Presentation_{timestamp}.pptx"
    prs.save(str(file_path))
    return str(file_path)

if __name__ == "__main__":
    path = create_ppt()
    print(f"PPT 已生成: {path}")
'''
        self.code_input.delete('1.0', tk.END)
        self.code_input.insert('1.0', example_code)
        self.hide_error()
        self.status_var.set("📋 已加载示例代码 (可直接点击运行查看效果)")

    def check_dependencies(self):
        try:
            import pptx
            self.pptx_available = True
        except ImportError:
            self.pptx_available = False
            self.status_var.set("⚠️ 缺少 python-pptx 库，首次运行时会引导安装")

    def show_error(self, error_msg):
        self.error_text.delete('1.0', tk.END)
        self.error_text.insert('1.0', error_msg)
        self.error_frame.pack(fill=tk.X, padx=20, pady=(0, 8))
        self.master.update()

    def hide_error(self):
        self.error_frame.pack_forget()

    def copy_error(self):
        error_content = self.error_text.get('1.0', tk.END).strip()
        if error_content:
            self.master.clipboard_clear()
            self.master.clipboard_append(error_content)
            self.status_var.set("✅ 错误信息已复制到剪贴板，粘贴到 AI 对话窗口即可")
            messagebox.showinfo("✅ 复制成功",
                                "错误信息已复制到剪贴板！\n\n"
                                "操作步骤：\n"
                                "1. 打开 AI 对话窗口（DeepSeek、ChatGPT 等）\n"
                                "2. 按 Ctrl+V 粘贴错误信息\n"
                                "3. 发送消息：'这是我运行PPT代码时的报错，请帮我修复'\n"
                                "4. AI 会给出修复后的代码，重新粘贴运行即可")

    def run_code(self):
        code = self.code_input.get('1.0', tk.END).strip()
        if not code:
            messagebox.showwarning("⚠️ 警告", "请输入或粘贴 PPT 生成代码")
            return

        self.hide_error()

        if not self.pptx_available:
            result = messagebox.askyesno("缺少依赖",
                                         "未检测到 python-pptx 库。\n是否现在安装？\n(需要网络连接)")
            if result:
                self.install_pptx()
            else:
                return

        temp_file = None
        try:
            # ============================================================
            # ★★★ 关键修复：在用户代码开头强制 UTF-8 ★★★
            # 这里就是你要加的位置！在写入临时文件之前！
            # ============================================================
            utf8_header = '''# -*- coding: utf-8 -*-
import sys
import io
# 强制 stdout/stderr 使用 UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
'''
            # 检查用户代码是否已有编码声明
            if not code.startswith('# -*- coding:'):
                full_code = utf8_header + code
            else:
                full_code = code
            # ============================================================

            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
                f.write(full_code)
                temp_file = f.name

            self.status_var.set("⏳ 正在生成 PPT...")
            self.master.update()

            # 获取 python.exe 路径
            if getattr(sys, 'frozen', False):
                exe_dir = os.path.dirname(sys.executable)
                python_exe = os.path.join(exe_dir, "python.exe")
                if not os.path.exists(python_exe):
                    python_exe = os.path.join(exe_dir, "python", "python.exe")
                if not os.path.exists(python_exe):
                    python_exe = "python"
            else:
                python_exe = sys.executable

            # ============================================================
            # ★★★ 子进程环境变量：强制 UTF-8 ★★★
            # ============================================================
            env = os.environ.copy()
            env['PYTHONIOENCODING'] = 'utf-8'
            env['PYTHONUTF8'] = '1'

            # 如果存在第三方库路径，添加到 PYTHONPATH
            if getattr(sys, 'frozen', False):
                exe_dir = os.path.dirname(sys.executable)
                lib_path = os.path.join(exe_dir, "Lib", "site-packages")
                if os.path.exists(lib_path):
                    env['PYTHONPATH'] = lib_path
            # ============================================================

            process = subprocess.Popen(
                [python_exe, temp_file],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding='utf-8',
                errors='replace',
                env=env  # ← 传递环境变量
            )
            stdout, stderr = process.communicate(timeout=30)

            stdout = stdout if stdout is not None else ""
            stderr = stderr if stderr is not None else ""

            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except:
                    pass

            if process.returncode == 0:
                self.status_var.set("✅ PPT 生成成功！正在尝试打开...")

                file_path = None
                for line in stdout.split('\n'):
                    if 'PPT 已生成:' in line:
                        parts = line.split('PPT 已生成:')
                        if len(parts) > 1:
                            file_path = parts[1].strip()
                            break
                    elif '.pptx' in line:
                        match = re.search(r'([A-Za-z]:\\[^\s]+\.pptx)', line)
                        if match:
                            file_path = match.group(1)
                            break
                        match = re.search(r'([^\s]+\.pptx)', line)
                        if match:
                            file_path = match.group(1)
                            break

                if file_path and os.path.exists(file_path):
                    try:
                        os.startfile(file_path)
                        self.status_var.set(f"✅ PPT 已打开: {os.path.basename(file_path)}")
                        return
                    except:
                        messagebox.showinfo("成功", f"PPT 已生成: {file_path}")
                        return

                filename = None
                for line in stdout.split('\n'):
                    if '.pptx' in line:
                        match = re.search(r'([^\s]+\.pptx)', line)
                        if match:
                            filename = match.group(1)
                            break

                if filename:
                    desktop = Path.home() / "Desktop"
                    target_file = desktop / filename
                    if target_file.exists():
                        try:
                            os.startfile(str(target_file))
                            self.status_var.set(f"✅ PPT 已打开: {filename}")
                            return
                        except:
                            pass

                desktop = Path.home() / "Desktop"
                pptx_files = list(desktop.glob("*.pptx"))
                if pptx_files:
                    latest = sorted(pptx_files, key=lambda p: p.stat().st_mtime, reverse=True)[0]
                    try:
                        os.startfile(str(latest))
                        self.status_var.set(f"✅ 找到并打开: {latest.name}")
                        return
                    except:
                        messagebox.showinfo("生成成功", f"PPT 已生成在桌面: {latest.name}")
                        return
                else:
                    messagebox.showinfo("生成成功", "PPT 已生成，但未找到文件。")
                    self.status_var.set("⚠️ 生成成功但未找到文件")

            else:
                error_full = stderr if stderr else stdout
                if not error_full:
                    error_full = "代码执行失败，但没有返回错误信息。"
                error_msg = f"❌ 代码执行失败 (返回码: {process.returncode})\n\n{error_full[:2000]}"
                self.show_error(error_msg)
                self.status_var.set("❌ 代码执行出错，点击「复制错误」发给 AI 修复")

        except subprocess.TimeoutExpired:
            self.show_error(
                "⏰ 执行超时 (30秒)\n\n"
                "可能原因：\n"
                "1. PPT 页数太多\n"
                "2. 代码中有死循环\n\n"
                "💡 建议：告诉 AI 「请精简PPT，控制在10页以内」"
            )
            self.status_var.set("⏰ 执行超时")
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except:
                    pass
        except Exception as e:
            error_msg = f"⚠️ 软件运行异常\n\n{traceback.format_exc()}"
            self.show_error(error_msg)
            self.status_var.set("❌ 发生异常")
            if temp_file and os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                except:
                    pass

    def install_pptx(self):
        try:
            self.status_var.set("⏳ 正在安装 python-pptx...")
            self.master.update()

            if getattr(sys, 'frozen', False):
                python_exe = os.path.join(os.path.dirname(sys.executable), "python.exe")
                if not os.path.exists(python_exe):
                    python_exe = "python"
            else:
                python_exe = sys.executable

            env = os.environ.copy()
            env['PYTHONIOENCODING'] = 'utf-8'

            subprocess.check_call([python_exe, "-m", "pip", "install", "python-pptx"], env=env)
            self.pptx_available = True
            self.status_var.set("✅ python-pptx 安装成功！")
            messagebox.showinfo("安装成功", "python-pptx 已安装，现在可以运行代码了。")
        except Exception as e:
            self.status_var.set("❌ 安装失败")
            messagebox.showerror("安装失败", f"无法安装 python-pptx:\n{str(e)}\n\n请手动安装: pip install python-pptx")


if __name__ == "__main__":
    root = tk.Tk()
    app = PPTCodeRunner(root)
    root.mainloop()
    if mutex:
        try:
            ctypes.windll.kernel32.ReleaseMutex(mutex)
        except:
            pass